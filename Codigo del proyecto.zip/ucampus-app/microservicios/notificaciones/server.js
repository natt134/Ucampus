// MICROSERVICIO DE NOTIFICACIONES: proceso independiente (puerto 4000) con su propio código y sus propios datos.
// Recibe eventos de UCampus y guarda avisos. Ejemplo didáctico: los datos viven en memoria.
const express = require('express');
const KEY = process.env.NOTIFICACIONES_KEY;
if (!KEY || KEY.length < 8) { console.error('Define NOTIFICACIONES_KEY (mín. 8 caracteres).'); process.exit(1); }

const app = express();
app.use(express.json({ limit: '50kb' }));
const avisos = [];

const conClave = (req, res, next) =>
  req.headers['x-api-key'] === KEY ? next() : res.status(401).json({ error: 'Clave de servicio inválida.' });

app.get('/salud', (req, res) => res.json({ ok: true, servicio: 'notificaciones' }));

app.post('/eventos', conClave, (req, res) => {
  const { evento, id, titulo, tipo, categoria, autor } = req.body || {};
  if (evento !== 'publicacion.creada' || !titulo) return res.status(400).json({ error: 'Evento no válido.' });
  const aviso = { id: avisos.length + 1, publicacion: id, mensaje: `Nuevo ${tipo} de ${categoria}: ${titulo}`, autor, fecha: new Date().toISOString() };
  avisos.unshift(aviso);
  if (avisos.length > 100) avisos.pop();
  res.status(201).json(aviso);
});

app.get('/notificaciones', conClave, (req, res) => res.json(avisos));

app.listen(process.env.PORT || 4000, () => console.log('Notificaciones en http://localhost:' + (process.env.PORT || 4000)));
