# UCampus · v0.3 (arquitectura hexagonal)

Express + MySQL 8 + JWT. El frontend (`public/index.html`) lo sirve el mismo servidor.

## Arquitectura hexagonal (puertos y adaptadores)
```
server.js                      raíz de composición: conecta adaptadores con la aplicación
src/domain/                    reglas de negocio puras (roles, validaciones, cupos, errores)
src/application/
  servicios.js                 casos de uso (puertos de entrada)
  puertos.js                   contratos que la infraestructura debe cumplir (puertos de salida)
src/adapters/in/http/          Express: traduce HTTP a casos de uso
src/adapters/out/mysql/        repositorios MySQL, transacciones y datos base
src/adapters/out/seguridad/    bcrypt (hash) y JWT (tokens)
test/                          pruebas de casos de uso con adaptadores falsos
```
La dependencia siempre apunta hacia adentro: los adaptadores conocen la aplicación y el dominio; el dominio no conoce a nadie. `npm test` ejecuta las pruebas sin necesitar MySQL.

## Puesta en marcha
1. Instala Node 18+ y MySQL 8.
2. `mysql -u root -p < schema.sql`
3. Copia `.env.example` a `.env` y completa la clave de MySQL y un `JWT_SECRET` largo.
4. `npm install`
5. `npm run seed`   (crea roles, categorías, usuarios y publicaciones de ejemplo)
6. `npm test` (opcional) y `npm start` → http://localhost:3000

## Crear cuenta
Desde el login, "Crear cuenta": cualquier correo, nombre, programa y contraseña (mín. 8). Toda cuenta nueva es **Estudiante**; el rol lo asigna solo el administrador desde la pestaña Usuarios.
Si ya habías ejecutado el seed antes, agrega programas con:
`INSERT INTO programas_academicos (nombre, codigo) VALUES ('Ingeniería Ambiental','IAMB'),('Administración de Empresas','ADEM');`

## Usuarios de prueba (clave: `Ucampus2026*`)
| Rol | Correo |
|---|---|
| Administrador | admin@ucundinamarca.edu.co |
| Bienestar | bienestar@ucundinamarca.edu.co · deportes@ucundinamarca.edu.co |
| Docente | camilo.pena@ucundinamarca.edu.co |
| Estudiante | valentina.rojas@ucundinamarca.edu.co · laura.mendez@ucundinamarca.edu.co |

## Permisos por rol
| Acción | Estudiante | Docente | Bienestar | Admin |
|---|:-:|:-:|:-:|:-:|
| Consultar, buscar, filtrar, guardar, dar me gusta, comentar | ✓ | ✓ | ✓ | ✓ |
| Inscribirse a eventos / postularse | ✓ | | | |
| Crear publicaciones | | | ✓ | ✓ |
| Editar / eliminar | | | solo las suyas | todas |
| Gestionar usuarios y roles | | | | ✓ |

Los permisos se validan en el servidor (JWT de 8 h); ocultar botones en la interfaz es solo comodidad.

## API
`POST /api/auth/login` · `POST /api/auth/registro` · `GET /api/programas` · `GET /api/auth/me` · `GET /api/categorias`
`GET|POST /api/publicaciones` · `PUT|DELETE /api/publicaciones/:id`
`POST /api/publicaciones/:id/{like|guardar|inscripcion}`
`GET|POST /api/publicaciones/:id/comentarios`
`GET /api/usuarios` · `GET /api/roles` · `PATCH /api/usuarios/:id/rol` (solo admin)

## Cambios respecto al diagrama ER
- `publicaciones` ahora tiene `tipo`, `titulo`, `id_categoria` e `id_evento` (opcional). `eventos` queda solo con lo propio del evento (fecha, lugar, cupo, requisitos).
- `eventos_guardados` → `publicaciones_guardadas` (también sirve para noticias).
- Tabla nueva `reacciones` (me gusta).
- Aún no se usan `materias`, `horarios` ni `estudiante_materia`; `espacios` es opcional y por ahora el lugar es texto libre.
