// ADAPTADOR DE ENTRADA (HTTP/Express): traduce peticiones a casos de uso.
// No contiene reglas de negocio ni SQL.
const express = require('express');
const path = require('path');
const { ErrorApp } = require('../../../domain/errores');

function crearApp(servicios, tokens) {
  const app = express();
  app.disable('x-powered-by');
  app.use((req, res, next) => {   // CORS solo para localhost (desarrollo)
    const o = req.headers.origin;
    if (o && /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(o)) {
      res.set({ 'Access-Control-Allow-Origin': o, 'Vary': 'Origin',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS' });
      if (req.method === 'OPTIONS') return res.sendStatus(204);
    }
    next();
  });
  app.use(express.json({ limit: '100kb' }));
  app.use(express.static(path.join(__dirname, '../../../../public')));

  const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res)).catch(next);
  const auth = (req, res, next) => {          // autenticación: el permiso por rol lo decide el caso de uso
    const h = req.headers.authorization || '';
    try { req.user = tokens.verificar(h.startsWith('Bearer ') ? h.slice(7) : ''); }
    catch { return res.status(401).json({ error: 'Tu sesión terminó. Inicia sesión de nuevo.' }); }
    next();
  };
  const intentos = new Map();                 // 8 intentos por IP cada 10 minutos
  const limitar = (req, res, next) => {
    const ahora = Date.now(), a = (intentos.get(req.ip) || []).filter(t => ahora - t < 600000);
    if (a.length >= 8) return res.status(429).json({ error: 'Demasiados intentos. Espera unos minutos.' });
    a.push(ahora); intentos.set(req.ip, a); next();
  };
  const r = (fn, estado = 200) => wrap(async (req, res) => res.status(estado).json(await fn(req)));

  app.post('/api/auth/login', limitar, r(req => servicios.iniciarSesion(req.body)));
  app.post('/api/auth/registro', limitar, r(req => servicios.registrar(req.body), 201));
  app.get('/api/programas', r(() => servicios.programas()));
  app.get('/api/auth/me', auth, r(req => ({ user: req.user })));
  app.get('/api/categorias', auth, r(() => servicios.categorias()));

  app.get('/api/publicaciones', auth, r(req => servicios.listarPublicaciones(req.user, req.query)));
  app.post('/api/publicaciones', auth, r(req => servicios.crearPublicacion(req.user, req.body), 201));
  app.put('/api/publicaciones/:id', auth, r(req => servicios.editarPublicacion(req.user, +req.params.id, req.body)));
  app.delete('/api/publicaciones/:id', auth, r(req => servicios.eliminarPublicacion(req.user, +req.params.id)));
  app.post('/api/publicaciones/:id/like', auth, r(req => servicios.alternarLike(req.user, +req.params.id)));
  app.post('/api/publicaciones/:id/guardar', auth, r(req => servicios.alternarGuardado(req.user, +req.params.id)));
  app.post('/api/publicaciones/:id/inscripcion', auth, r(req => servicios.alternarInscripcion(req.user, +req.params.id)));
  app.get('/api/publicaciones/:id/comentarios', auth, r(req => servicios.comentarios(+req.params.id)));
  app.post('/api/publicaciones/:id/comentarios', auth, r(req => servicios.comentar(req.user, +req.params.id, (req.body || {}).contenido), 201));

  app.get('/api/usuarios', auth, r(req => servicios.listarUsuarios(req.user)));
  app.get('/api/roles', auth, r(req => servicios.listarRoles(req.user)));
  app.patch('/api/usuarios/:id/rol', auth, r(req => servicios.cambiarRol(req.user, +req.params.id, (req.body || {}).rol)));

  app.use('/api', (req, res) => res.status(404).json({ error: 'Ruta no encontrada.' }));
  app.use((e, req, res, next) => {
    if (e instanceof ErrorApp) return res.status(e.estado).json({ error: e.message });
    console.error(e);
    res.status(500).json({ error: 'Error del servidor. Intenta de nuevo en un momento.' });
  });
  return app;
}
module.exports = { crearApp };
