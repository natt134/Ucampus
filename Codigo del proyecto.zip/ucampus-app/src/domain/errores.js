// Errores del dominio. El adaptador HTTP los traduce a códigos de estado.
class ErrorApp extends Error {
  constructor(estado, mensaje) { super(mensaje); this.estado = estado; }
}
const E = {
  invalido: m => new ErrorApp(400, m),
  noAutenticado: m => new ErrorApp(401, m),
  prohibido: m => new ErrorApp(403, m),
  noEncontrado: m => new ErrorApp(404, m),
  conflicto: m => new ErrorApp(409, m)
};
module.exports = { ErrorApp, E };
