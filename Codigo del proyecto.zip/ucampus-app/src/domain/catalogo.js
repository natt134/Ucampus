// Datos base oficiales (sin dependencias de infraestructura).
const ROLES = [['ESTUDIANTE', 'Consulta, comenta e inscribe'], ['DOCENTE', 'Consulta y comenta'],
  ['BIENESTAR', 'Publica y gestiona sus publicaciones'], ['ADMIN', 'Gestiona usuarios, roles y publicaciones']];
const FI = 'Facultad de Ingeniería', FA = 'Facultad de Ciencias Administrativas, Económicas y Contables',
  FG = 'Facultad de Ciencias Agropecuarias', FS = 'Facultad de Ciencias de la Salud',
  FH = 'Facultad de Ciencias Sociales, Humanidades y Ciencias de la Educación';
const PROGRAMAS = [ // [facultad, programa, código]
  [FI, 'Ingeniería de Sistemas y Computación', 'ISIS'], [FI, 'Ingeniería Electrónica', 'IELE'],
  [FI, 'Ingeniería Industrial', 'IIND'], [FI, 'Ingeniería Ambiental', 'IAMB'],
  [FI, 'Ingeniería Agronómica', 'IAGR'], [FI, 'Ingeniería Topográfica y Geomática', 'ITOP'],
  [FI, 'Ingeniería de Software', 'ISOF'], [FI, 'Ingeniería Mecatrónica', 'IMEC'],
  [FA, 'Administración de Empresas', 'ADEM'], [FA, 'Contaduría Pública', 'CONT'],
  [FG, 'Zootecnia', 'ZOOT'], [FG, 'Medicina Veterinaria y Zootecnia', 'MVET'],
  [FS, 'Enfermería', 'ENFE'],
  [FH, 'Psicología', 'PSIC'], [FH, 'Licenciatura en Ciencias Sociales', 'LCSO'],
  [FH, 'Música', 'MUSI'], [FH, 'Profesional en Ciencias del Deporte', 'PCDE']];
const CATEGORIAS = ['ACADÉMICO', 'DEPORTIVO', 'CULTURAL', 'BIENESTAR', 'TALLER'];
module.exports = { ROLES, PROGRAMAS, CATEGORIAS };
