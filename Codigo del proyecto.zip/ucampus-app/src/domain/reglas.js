// Reglas de negocio puras: no conocen Express, MySQL, bcrypt ni JWT.
const { E } = require('./errores');

const ROLES = { ESTUDIANTE: 'ESTUDIANTE', DOCENTE: 'DOCENTE', BIENESTAR: 'BIENESTAR', ADMIN: 'ADMIN' };
const ROLES_QUE_PUBLICAN = [ROLES.BIENESTAR, ROLES.ADMIN];
const TIPOS = ['evento', 'convocatoria', 'noticia'];

const puedePublicar = rol => ROLES_QUE_PUBLICAN.includes(rol);
// Bienestar solo modifica lo suyo; el administrador, todo.
const puedeModificar = (usuario, pub) => usuario.rol === ROLES.ADMIN || (puedePublicar(usuario.rol) && pub.idUsuario === usuario.id);
const hayCupo = (confirmadas, cupo) => !cupo || confirmadas < cupo;

function validarPublicacion(b = {}, tipoFijo) {
  const tipo = tipoFijo || b.tipo;
  const titulo = String(b.titulo || '').trim(), contenido = String(b.contenido || '').trim();
  if (!TIPOS.includes(tipo)) throw E.invalido('Tipo de publicación no válido.');
  if (titulo.length < 3 || titulo.length > 150) throw E.invalido('El título debe tener entre 3 y 150 caracteres.');
  if (!contenido) throw E.invalido('Escribe la descripción de la publicación.');
  let fecha = null;
  if (tipo !== 'noticia') {
    fecha = new Date(b.fecha);
    if (!b.fecha || isNaN(fecha)) throw E.invalido('Los eventos y convocatorias necesitan una fecha válida.');
  }
  return { tipo, titulo, contenido, categoria: String(b.categoria || ''), fecha,
    cupo: Math.max(0, parseInt(b.cupo, 10) || 0), lugar: String(b.lugar || '').trim().slice(0, 150) };
}

function validarRegistro(b = {}) {
  const nombres = String(b.nombres || '').trim().slice(0, 100), apellidos = String(b.apellidos || '').trim().slice(0, 100);
  const correo = String(b.correo || '').trim().toLowerCase(), password = String(b.password || '');
  if (!nombres || !apellidos) throw E.invalido('Escribe tus nombres y apellidos.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo) || correo.length > 150) throw E.invalido('Escribe un correo válido.');
  if (password.length < 8 || password.length > 72) throw E.invalido('La contraseña debe tener entre 8 y 72 caracteres.');
  return { nombres, apellidos, correo, password, programa: b.programa };
}

function validarComentario(texto) {
  const t = String(texto || '').trim();
  if (!t) throw E.invalido('Escribe algo antes de enviar el comentario.');
  if (t.length > 1000) throw E.invalido('El comentario no puede superar 1000 caracteres.');
  return t;
}

const nombreUsuarioBase = correo => correo.split('@')[0].replace(/[^a-z0-9._-]/g, '').slice(0, 40) || 'usuario';

module.exports = { ROLES, ROLES_QUE_PUBLICAN, TIPOS, puedePublicar, puedeModificar, hayCupo,
  validarPublicacion, validarRegistro, validarComentario, nombreUsuarioBase };
