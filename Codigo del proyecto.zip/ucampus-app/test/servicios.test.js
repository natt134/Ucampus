// Pruebas de los casos de uso con adaptadores falsos en memoria (sin MySQL, Express ni bcrypt).
const test = require('node:test');
const assert = require('node:assert/strict');
const { crearServicios } = require('../src/application/servicios');
const { verificarPuerto } = require('../src/application/puertos');
const { crearRepositorios } = require('../src/adapters/out/mysql/repositorios');
const { ErrorApp } = require('../src/domain/errores');

const hasher = { hash: async t => 'h:' + t, comparar: async (t, h) => h === 'h:' + t };
const tokens = { firmar: p => JSON.stringify(p), verificar: t => JSON.parse(t) };

function montar({ cupo = 2, confirmadas = 0 } = {}) {
  const e = { usuarios: [{ id: 1, nombre: 'Ana Lopez', rol: 'ESTUDIANTE', passwordHash: 'h:clave1234', correo: 'ana@x.co' }],
    creados: [], inscritos: confirmadas, inscripcion: null, publicaciones: { 7: { idUsuario: 20, idEvento: 5, tipo: 'evento' } } };
  const repos = {
    usuarios: {
      buscarParaLogin: async u => e.usuarios.find(x => x.correo === u) || null,
      existeCorreo: async c => e.usuarios.some(x => x.correo === c),
      existeNombreUsuario: async () => false,
      idRol: async n => ({ ESTUDIANTE: 1, ADMIN: 4 })[n] || null,
      crearEstudiante: async d => { e.creados.push(d); return 99; },
      idEstudiante: async () => 55,
      cambiarRol: async () => true
    },
    catalogo: { programaActivo: async id => id === 1, idCategoria: async n => (n === 'CULTURAL' ? 3 : null) },
    publicaciones: {
      buscarActiva: async id => e.publicaciones[id] || null,
      crear: async () => 11, actualizar: async () => {}, eliminar: async () => {}, comentar: async () => {},
      bloquearEvento: async () => ({ idEvento: 5, cupoMaximo: cupo }),
      inscripcionConfirmada: async () => e.inscripcion,
      cancelarInscripcion: async () => { e.inscripcion = null; e.inscritos--; },
      contarConfirmadas: async () => e.inscritos,
      inscribir: async () => { e.inscripcion = 1; e.inscritos++; }
    }
  };
  const uow = { ejecutar: fn => fn(repos) };
  return { s: crearServicios({ repos, uow, hasher, tokens }), e };
}
const rechaza = (p, estado) => assert.rejects(p, x => x instanceof ErrorApp && x.estado === estado);
const estudiante = { id: 1, rol: 'ESTUDIANTE' }, bienestar = { id: 20, rol: 'BIENESTAR' }, otro = { id: 21, rol: 'BIENESTAR' }, admin = { id: 2, rol: 'ADMIN' };
const pub = { tipo: 'evento', titulo: 'Noche de talentos', contenido: 'Música y danza', categoria: 'CULTURAL', fecha: '2026-11-01' };

test('los repositorios MySQL cumplen los puertos', () => {
  const r = crearRepositorios({ query: async () => [[]] });
  verificarPuerto('repoUsuarios', r.usuarios); verificarPuerto('repoCatalogo', r.catalogo); verificarPuerto('repoPublicaciones', r.publicaciones);
});
test('login correcto devuelve token y rol; incorrecto da 401', async () => {
  const { s } = montar();
  const j = await s.iniciarSesion({ usuario: 'ana@x.co', password: 'clave1234' });
  assert.equal(j.user.rol, 'ESTUDIANTE'); assert.ok(j.token);
  await rechaza(s.iniciarSesion({ usuario: 'ana@x.co', password: 'mala' }), 401);
});
test('registro crea siempre un ESTUDIANTE aunque el cliente pida ADMIN', async () => {
  const { s, e } = montar();
  const j = await s.registrar({ nombres: 'Luis', apellidos: 'Gil', correo: 'luis@x.co', password: 'clave1234', programa: 1, rol: 'ADMIN' });
  assert.equal(j.user.rol, 'ESTUDIANTE'); assert.equal(e.creados[0].idRol, 1);
  await rechaza(s.registrar({ nombres: 'Ana', apellidos: 'Lopez', correo: 'ana@x.co', password: 'clave1234', programa: 1 }), 409);
  await rechaza(s.registrar({ nombres: 'A', apellidos: 'B', correo: 'a@x.co', password: 'corta', programa: 1 }), 400);
});
test('solo Bienestar y Admin crean publicaciones', async () => {
  const { s } = montar();
  await rechaza(s.crearPublicacion(estudiante, pub), 403);
  assert.deepEqual(await s.crearPublicacion(bienestar, pub), { id: 11 });
  await rechaza(s.crearPublicacion(bienestar, { ...pub, fecha: '' }), 400);
});
test('Bienestar edita lo suyo, no lo ajeno; Admin edita todo', async () => {
  const { s } = montar();
  assert.deepEqual(await s.editarPublicacion(bienestar, 7, pub), { ok: true });
  await rechaza(s.editarPublicacion(otro, 7, pub), 403);
  assert.deepEqual(await s.eliminarPublicacion(admin, 7), { ok: true });
  await rechaza(s.eliminarPublicacion(admin, 999), 404);
});
test('inscripción alterna y respeta el cupo', async () => {
  const { s } = montar({ cupo: 1, confirmadas: 1 });
  await rechaza(s.alternarInscripcion(estudiante, 7), 409);
  await rechaza(s.alternarInscripcion(bienestar, 7), 403);
  const libre = montar({ cupo: 2, confirmadas: 0 });
  assert.deepEqual(await libre.s.alternarInscripcion(estudiante, 7), { activo: true });
  assert.deepEqual(await libre.s.alternarInscripcion(estudiante, 7), { activo: false });
});
test('no se aceptan comentarios vacíos', async () => {
  const { s } = montar();
  await rechaza(s.comentar(estudiante, 7, '   '), 400);
  assert.deepEqual(await s.comentar(estudiante, 7, 'Hola'), { ok: true });
});
test('el administrador no puede cambiar su propio rol y los demás no gestionan usuarios', async () => {
  const { s } = montar();
  await rechaza(s.cambiarRol(admin, 2, 'ESTUDIANTE'), 400);
  await rechaza(s.cambiarRol(estudiante, 5, 'ADMIN'), 403);
  assert.deepEqual(await s.cambiarRol(admin, 5, 'ADMIN'), { ok: true });
});
