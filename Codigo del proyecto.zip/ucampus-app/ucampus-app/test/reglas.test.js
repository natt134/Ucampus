// Pruebas del dominio (reglas puras). Escritas ANTES de la corrección (ciclo TDD).
const test = require('node:test');
const assert = require('node:assert/strict');
const { validarPublicacion } = require('../src/domain/reglas');
const { ErrorApp } = require('../src/domain/errores');

const base = { tipo: 'evento', titulo: 'Feria de proyectos', contenido: 'Muestra de proyectos', categoria: 'ACADÉMICO' };

test('una fecha sin hora se guarda ese mismo día a las 12:00 hora local', () => {
  const f = validarPublicacion({ ...base, fecha: '2026-11-01' }).fecha;
  assert.deepEqual([f.getFullYear(), f.getMonth(), f.getDate(), f.getHours()], [2026, 10, 1, 12]);
});
test('la hora indicada se respeta (HU09: fecha y hora del evento)', () => {
  const f = validarPublicacion({ ...base, fecha: '2026-11-12', hora: '15:30' }).fecha;
  assert.deepEqual([f.getDate(), f.getHours(), f.getMinutes()], [12, 15, 30]);
});
test('una hora inválida se rechaza con 400', () => {
  assert.throws(() => validarPublicacion({ ...base, fecha: '2026-11-12', hora: '25:99' }),
    e => e instanceof ErrorApp && e.estado === 400);
});
