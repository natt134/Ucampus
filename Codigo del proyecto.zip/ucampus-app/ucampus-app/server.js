// RAÍZ DE COMPOSICIÓN: único lugar que conoce todos los adaptadores y los conecta con la aplicación.
require('dotenv').config();
const { verificarPuerto } = require('./src/application/puertos');
const { crearServicios } = require('./src/application/servicios');
const { crearPool } = require('./src/adapters/out/mysql/conexion');
const { crearRepositorios, crearUnidadDeTrabajo } = require('./src/adapters/out/mysql/repositorios');
const { asegurarDatosBase } = require('./src/adapters/out/mysql/datosBase');
const hasher = require('./src/adapters/out/seguridad/bcryptHasher');
const { crearTokens } = require('./src/adapters/out/seguridad/jwtTokens');
const { crearNotificadorHttp } = require('./src/adapters/out/http/notificadorHttp');
const { crearApp } = require('./src/adapters/in/http/app');

const SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET.length < 16) { console.error('Define JWT_SECRET (mín. 16 caracteres) en .env'); process.exit(1); }

const pool = crearPool(process.env);
const repos = crearRepositorios(pool);
verificarPuerto('repoUsuarios', repos.usuarios);
verificarPuerto('repoCatalogo', repos.catalogo);
verificarPuerto('repoPublicaciones', repos.publicaciones);
const uow = verificarPuerto('unidadDeTrabajo', crearUnidadDeTrabajo(pool));
verificarPuerto('hasher', hasher);
const tokens = verificarPuerto('tokens', crearTokens(SECRET));

// Microservicio opcional: si NOTIFICACIONES_URL no está definida, no se avisa a nadie.
const notificador = verificarPuerto('notificador', process.env.NOTIFICACIONES_URL
  ? crearNotificadorHttp(process.env.NOTIFICACIONES_URL, process.env.NOTIFICACIONES_KEY)
  : { publicacionCreada: async () => {} });

const app = crearApp(crearServicios({ repos, uow, hasher, tokens, notificador }), tokens);
const PORT = process.env.PORT || 3000;
asegurarDatosBase(pool)
  .then(() => app.listen(PORT, () => console.log(`UCampus en http://localhost:${PORT}`)))
  .catch(e => { console.error('No se pudo conectar con la base de datos. Revisa .env y que schema.sql esté ejecutado.\n', e.message); process.exit(1); });
