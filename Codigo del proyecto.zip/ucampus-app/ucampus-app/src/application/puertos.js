// PUERTOS DE SALIDA: contratos que la aplicación necesita de la infraestructura.
// Cada adaptador debe implementar todos los métodos de su puerto.
const PUERTOS = {
  repoUsuarios: ['buscarParaLogin', 'existeCorreo', 'existeNombreUsuario', 'idRol', 'crearEstudiante',
    'idEstudiante', 'listarActivos', 'nombresDeRoles', 'cambiarRol'],
  repoCatalogo: ['categorias', 'idCategoria', 'programas', 'programaActivo'],
  repoPublicaciones: ['listar', 'buscarActiva', 'crear', 'actualizar', 'eliminar', 'alternarReaccion',
    'alternarGuardado', 'comentarios', 'comentar', 'bloquearEvento', 'inscripcionConfirmada',
    'cancelarInscripcion', 'contarConfirmadas', 'inscribir'],
  hasher: ['hash', 'comparar'],
  tokens: ['firmar', 'verificar'],
  notificador: ['publicacionCreada'],   // avisa a otro servicio (microservicio de notificaciones)
  unidadDeTrabajo: ['ejecutar']   // ejecutar(fn(repos)) corre fn dentro de una transacción
};
function verificarPuerto(nombre, impl) {
  const faltan = PUERTOS[nombre].filter(m => typeof impl[m] !== 'function');
  if (faltan.length) throw new Error(`El adaptador no cumple el puerto ${nombre}; faltan: ${faltan.join(', ')}`);
  return impl;
}
module.exports = { PUERTOS, verificarPuerto };
