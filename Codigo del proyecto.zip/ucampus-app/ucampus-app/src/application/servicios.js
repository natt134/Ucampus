// CASOS DE USO (puertos de entrada). Orquestan el dominio usando solo puertos.
const { E } = require('../domain/errores');
const R = require('../domain/reglas');

const exigirRol = (u, ...roles) => {
  if (!roles.includes(u.rol)) throw E.prohibido('Tu rol no tiene permiso para esta acción.');
};

const sinNotificador = { publicacionCreada: async () => {} };

function crearServicios({ repos, uow, hasher, tokens, notificador = sinNotificador }) {
  const emitir = u => ({ token: tokens.firmar({ id: u.id, nombre: u.nombre, rol: u.rol }), user: { id: u.id, nombre: u.nombre, rol: u.rol } });
  const categoria = async nombre => {
    const id = await repos.catalogo.idCategoria(nombre);
    if (!id) throw E.invalido('Selecciona una categoría válida.');
    return id;
  };
  const propia = async (u, id) => {
    exigirRol(u, ...R.ROLES_QUE_PUBLICAN);
    const p = await repos.publicaciones.buscarActiva(id);
    if (!p) throw E.noEncontrado('La publicación no existe.');
    if (!R.puedeModificar(u, p)) throw E.prohibido('Solo puedes modificar tus propias publicaciones.');
    return p;
  };

  return {
    /* acceso */
    async iniciarSesion({ usuario, password } = {}) {
      if (!usuario || !password) throw E.invalido('Ingresa tu correo o usuario y tu contraseña.');
      const u = await repos.usuarios.buscarParaLogin(usuario);
      if (!u || !(await hasher.comparar(password, u.passwordHash))) throw E.noAutenticado('Correo o contraseña incorrectos.');
      return emitir(u);
    },
    async registrar(body) {
      const d = R.validarRegistro(body);                       // el rol nunca viene del cliente
      if (!(await repos.catalogo.programaActivo(d.programa))) throw E.invalido('Selecciona tu programa académico.');
      if (await repos.usuarios.existeCorreo(d.correo)) throw E.conflicto('Ya existe una cuenta con ese correo. Inicia sesión.');
      let nombreUsuario = R.nombreUsuarioBase(d.correo);
      while (await repos.usuarios.existeNombreUsuario(nombreUsuario))
        nombreUsuario = nombreUsuario.slice(0, 40) + Math.floor(Math.random() * 9000 + 1000);
      const idRol = await repos.usuarios.idRol(R.ROLES.ESTUDIANTE);
      const passwordHash = await hasher.hash(d.password);
      const id = await uow.ejecutar(r => r.usuarios.crearEstudiante({ idRol, nombreUsuario, correo: d.correo,
        passwordHash, nombres: d.nombres, apellidos: d.apellidos, idPrograma: d.programa }));
      return emitir({ id, nombre: `${d.nombres} ${d.apellidos}`, rol: R.ROLES.ESTUDIANTE });
    },

    /* catálogos */
    categorias: () => repos.catalogo.categorias(),
    programas: () => repos.catalogo.programas(),

    /* publicaciones */
    listarPublicaciones: (u, filtros = {}) => repos.publicaciones.listar(u.id, filtros),
    async crearPublicacion(u, body) {
      exigirRol(u, ...R.ROLES_QUE_PUBLICAN);
      const d = R.validarPublicacion(body);
      const idCategoria = await categoria(d.categoria);
      const id = await uow.ejecutar(r => r.publicaciones.crear({ ...d, idCategoria, idUsuario: u.id }));
      // Aviso asíncrono: si el microservicio está caído, la publicación igual se guarda.
      Promise.resolve().then(() => notificador.publicacionCreada({ id, titulo: d.titulo, tipo: d.tipo, categoria: d.categoria, autor: u.nombre })).catch(() => {});
      return { id };
    },
    async editarPublicacion(u, id, body) {
      const p = await propia(u, id);
      const d = R.validarPublicacion(body, p.tipo);            // el tipo no cambia al editar
      const idCategoria = await categoria(d.categoria);
      await uow.ejecutar(r => r.publicaciones.actualizar(id, p.idEvento, { ...d, idCategoria }));
      return { ok: true };
    },
    async eliminarPublicacion(u, id) {
      await propia(u, id);
      await repos.publicaciones.eliminar(id);                  // eliminación lógica
      return { ok: true };
    },

    /* interacción */
    async alternarLike(u, id) { return { activo: await repos.publicaciones.alternarReaccion(id, u.id) }; },
    async alternarGuardado(u, id) { return { activo: await repos.publicaciones.alternarGuardado(id, u.id) }; },
    comentarios: id => repos.publicaciones.comentarios(id),
    async comentar(u, id, texto) {
      await repos.publicaciones.comentar(id, u.id, R.validarComentario(texto));
      return { ok: true };
    },
    async alternarInscripcion(u, id) {
      exigirRol(u, R.ROLES.ESTUDIANTE);
      return uow.ejecutar(async r => {                         // transacción: el cupo no se supera
        const ev = await r.publicaciones.bloquearEvento(id);
        const est = await r.usuarios.idEstudiante(u.id);
        if (!ev || !est) throw E.noEncontrado('Esta publicación no admite inscripción.');
        const ya = await r.publicaciones.inscripcionConfirmada(ev.idEvento, est);
        if (ya) { await r.publicaciones.cancelarInscripcion(ya); return { activo: false }; }
        const n = await r.publicaciones.contarConfirmadas(ev.idEvento);
        if (!R.hayCupo(n, ev.cupoMaximo)) throw E.conflicto('El cupo ya está lleno.');
        await r.publicaciones.inscribir(ev.idEvento, est);
        return { activo: true };
      });
    },

    /* administración */
    async listarUsuarios(u) { exigirRol(u, R.ROLES.ADMIN); return repos.usuarios.listarActivos(); },
    async listarRoles(u) { exigirRol(u, R.ROLES.ADMIN); return repos.usuarios.nombresDeRoles(); },
    async cambiarRol(u, id, rol) {
      exigirRol(u, R.ROLES.ADMIN);
      if (+id === u.id) throw E.invalido('No puedes cambiar tu propio rol.');
      const idRol = await repos.usuarios.idRol(rol);
      if (!idRol) throw E.invalido('Rol no válido.');
      if (!(await repos.usuarios.cambiarRol(id, idRol))) throw E.noEncontrado('El usuario no existe.');
      return { ok: true };
    }
  };
}
module.exports = { crearServicios };
